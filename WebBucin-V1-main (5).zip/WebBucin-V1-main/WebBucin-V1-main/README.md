# WebBucin-Rio
Web Bucin Rio khusus buat grace tercinta &amp; tersayang. kalo lu mau buat ya fork sendiri

# Demo Site
 <a Comming Soon /</a>

# Let's connect with me!
<p>
    <a href="https://rioprojectx.tk" target="_blank"><img src="https://img.shields.io/badge/Website-https://sanrio.tk-blue?" /></a>
    <a href="https://www.linkedin.com/in/wafa-rifqi-anafin-553b591b7/" target="_blank"><img src="https://img.shields.io/badge/Linkedin-Rio-blue" /></a>
    <a href="https://instagram.com/san.rio31" target="_blank"><img src="https://img.shields.io/badge/Instagram-@san.rio31-blue" /></a>
</p> 
# WebBucin-V2
Web Bucin V2 khusus buat orang tercinta &amp; tersayang.

# Demo Site
 <a Comming Soon /</a>

# Let's connect with me!
<p>
    <a href="https://sanrio.com" target="_blank"><img src="https://img.shields.io/badge/Website-https://sanrio.com-blue?" /></a>
    <a href="https://www.linkedin.com/in/wafa-rifqi-anafin-553b591b7/" target="_blank"><img src="https://img.shields.io/badge/Linkedin-Rio-blue" /></a>
    <a href="https://instagram.com/san.rio31" target="_blank"><img src="https://img.shields.io/badge/Instagram-@san.rio31-blue" /></a>
</p> 
 
 
 # Let's Be Friends
 * [Telegram](t.me/fckualot) Rio At Telegram
 * [Instagram](instagram.com/san.rio31) Rio At Instagram
 * [Telegram Group](t.me/riogroupsupport) Telegram Group For Disscus About This Project
